<x-uts-layout>
    <div class="container">
        <h1>About</h1>
    </div>
</x-uts-layout>