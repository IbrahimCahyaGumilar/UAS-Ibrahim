<x-base-layout>
    <div class="container">
        <h1>Tugas UTS pindah kesini</h1>
    </div>
</x-base-layout>
